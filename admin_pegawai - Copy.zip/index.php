<?php

header('Location: public/');